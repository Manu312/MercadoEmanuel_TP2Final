class Sondas{
    sondas = [];
    constructor(){
        this.sondas = [];
    }
    createSondas = async (sonda) => {
        console.log("model sonda")
        this.sondas.push(sonda);
        return "create onda ok";
    };
    getAllSondas = async () =>{
        return this.sondas;
    }
    getSondasById = async (id) =>{
        const result = this.sondas.filter(onda => onda.id === id);
        if (result.length > 0) {
            return result;
        } else {
            return `No se encontró ninguna sonda con el id: ${id}`;
        }
    }
    deleteAllSondas = async () =>{
        this.sondas=[];
        return "delete onda all ok";
    }
}
export default Sondas;